
const mongoose = require('mongoose')

 

const school= mongoose.Schema({
    stdid:{
        type:String
    },
    name:{
        type:String
    },
    lastname:{
        type:String
    }
})


const student = mongoose.model('student',school);
module.exports = student
