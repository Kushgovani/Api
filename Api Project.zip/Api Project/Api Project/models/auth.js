
const mongoose = require("mongoose");
const validator = require("validator");
const bcrypt = require("bcryptjs");

const userschema = mongoose.Schema({
  username: {
    type: String,
  },
  email: {
    type: String,
    uniqued: true,
    validator: [validator.email, "Please Enter your email"],
  },
  password: {
    type: String,
    require: [true, "Please Enter your Password"],
    minlength: 6,
    select: false,
  },
});


userschema.pre("save", async function (next) {
  if (!this.isModified("password")) return next;
  this.password = await bcrypt.hash(this.password, 10);
  next();
});


const User = mongoose.model("user", userschema);
module.exports = User;
