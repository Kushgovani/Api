// -------PRODUCT :----------------------------------
const mongoose = require('mongoose');
 
const prod = mongoose.Schema({
    watchname:{
        type:String
    },
    price:{
        type:String
    },
    product_id:{
        type:String
    }
 
})
 

const product = mongoose.model('product', prod);
module.exports = product